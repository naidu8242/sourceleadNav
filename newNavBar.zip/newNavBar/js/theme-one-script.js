// JavaScript Document
		$('.side-menu').click(function(){
			$("div.side-nav ul li").find('.tree-view').toggleClass("tree-view-new-active");
			$("div.side-nav ul li").find('ul.collapses, .tree-view-new-active').toggleClass('tree-view-active');
			});
