// JavaScript Document

function init()
  {
	$('.demoDiv').ekScrollable();
  }